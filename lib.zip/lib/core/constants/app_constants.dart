class AppConstants {
  static const String appName = 'Fox Link App';

  // Roles
  static const String roleAdmin = 'admin';
  static const String roleProfessional = 'professional';
  static const String roleClient = 'client';
}