class AuthUser {
  final String uid;
  final String email;

  AuthUser({
    required this.uid,
    required this.email,
  });
}